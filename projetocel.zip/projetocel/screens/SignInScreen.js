import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';

export default function SignInScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  function handleSignIn() {
    if (!email.trim() || !password.trim()) {
      Alert.alert(
        'Atenção',
        'Preencha o e-mail e a senha.'
      );

      return;
    }

    Alert.alert(
      'Login',
      `E-mail informado: ${email}`
    );
  }

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-white"
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#ffffff"
      />

      <ScrollView
        contentContainerStyle={{
          flexGrow: 1,
        }}
        keyboardShouldPersistTaps="handled"
      >
        <View className="flex-1 px-6 py-12">

          {/* Botão voltar */}
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            className="mb-10"
          >
            <Text className="text-lg font-bold text-green-500">
              ← Voltar
            </Text>
          </TouchableOpacity>

          {/* Área superior */}
          <View className="mb-10">

            <View className="mb-8 h-24 w-24 items-center justify-center rounded-full bg-green-100">
              <Text className="text-4xl font-bold text-green-500">
                $
              </Text>
            </View>

            <Text className="text-4xl font-bold text-gray-800">
              Sign In
            </Text>

            <Text className="mt-2 text-base text-gray-500">
              Entre na sua conta para continuar.
            </Text>

          </View>

          {/* Campo de e-mail */}
          <Text className="mb-2 font-semibold text-gray-700">
            Email
          </Text>

          <TextInput
            value={email}
            onChangeText={setEmail}
            placeholder="Digite seu e-mail"
            placeholderTextColor="#9ca3af"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            className="mb-5 rounded-xl border border-gray-300 px-4 py-4 text-base text-gray-800"
          />

          {/* Campo de senha */}
          <Text className="mb-2 font-semibold text-gray-700">
            Password
          </Text>

          <TextInput
            value={password}
            onChangeText={setPassword}
            placeholder="Digite sua senha"
            placeholderTextColor="#9ca3af"
            secureTextEntry
            className="rounded-xl border border-gray-300 px-4 py-4 text-base text-gray-800"
          />

          {/* Esqueci a senha */}
          <TouchableOpacity
            className="mt-3 self-end"
          >
            <Text className="font-semibold text-green-500">
              Forgot Password?
            </Text>
          </TouchableOpacity>

          {/* Botão Sign In */}
          <TouchableOpacity
            onPress={handleSignIn}
            className="mt-8 rounded-xl bg-green-500 py-4"
          >
            <Text className="text-center text-lg font-bold text-white">
              Sign In
            </Text>
          </TouchableOpacity>

          {/* Ir para cadastro */}
          <View className="mt-8 flex-row justify-center">

            <Text className="text-gray-500">
              Don't have an account?
            </Text>

            <TouchableOpacity
              onPress={() => navigation.navigate('SignUp')}
            >
              <Text className="ml-2 font-bold text-green-500">
                Sign Up
              </Text>
            </TouchableOpacity>

          </View>

        </View>
      </ScrollView>

    </KeyboardAvoidingView>
  );
}