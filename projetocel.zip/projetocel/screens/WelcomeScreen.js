
import React from 'react';

import {
  View,
  Text,
  TouchableOpacity,
  StatusBar,
} from 'react-native';

export default function WelcomeScreen({ navigation }) {
  return (
    <View className="flex-1 bg-white px-6">

      <StatusBar
        barStyle="dark-content"
        backgroundColor="#ffffff"
      />

      <View className="flex-1 items-center justify-center">

        <View className="h-52 w-52 items-center justify-center rounded-full bg-green-100">
          <Text className="text-6xl font-bold text-green-500">
            $
          </Text>
        </View>

        <Text className="mt-10 text-4xl font-bold text-gray-800">
          Expensify
        </Text>

        <Text className="mt-3 text-center text-base text-gray-500">
          Controle suas despesas de forma simples e organizada.
        </Text>

      </View>

      <View className="pb-12">

        <TouchableOpacity
          onPress={() => navigation.navigate('SignIn')}
          className="rounded-2xl bg-green-500 py-4"
        >
          <Text className="text-center text-lg font-bold text-white">
            Sign In
          </Text>
        </TouchableOpacity>

        <View className="mt-6 flex-row justify-center">

          <Text className="text-gray-500">
            Don't have an account?
          </Text>

          <TouchableOpacity
            onPress={() => navigation.navigate('SignUp')}
          >
            <Text className="ml-2 font-bold text-green-500">
              Sign Up
            </Text>
          </TouchableOpacity>

        </View>

      </View>

    </View>
  );
}