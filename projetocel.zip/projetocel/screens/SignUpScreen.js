
import React, { useState } from 'react';

import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
  Alert,
} from 'react-native';

export default function SignUpScreen({ navigation }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  function handleSignUp() {
    if (
      !name.trim() ||
      !email.trim() ||
      !password.trim() ||
      !confirmPassword.trim()
    ) {
      Alert.alert(
        'Atenção',
        'Preencha todos os campos.'
      );

      return;
    }

    if (password !== confirmPassword) {
      Alert.alert(
        'Atenção',
        'As senhas não são iguais.'
      );

      return;
    }

    Alert.alert(
      'Cadastro',
      `Conta de ${name} criada com sucesso.`
    );
  }

  return (
    <KeyboardAvoidingView
      className="flex-1 bg-white"
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <StatusBar
        barStyle="dark-content"
        backgroundColor="#ffffff"
      />

      <ScrollView
        contentContainerStyle={{
          flexGrow: 1,
        }}
        keyboardShouldPersistTaps="handled"
      >
        <View className="flex-1 px-6 py-12">

          <TouchableOpacity
            onPress={() => navigation.goBack()}
            className="mb-8"
          >
            <Text className="text-lg font-bold text-green-500">
              ← Voltar
            </Text>
          </TouchableOpacity>

          <View className="mb-8">

            <View className="mb-6 h-24 w-24 items-center justify-center rounded-full bg-green-100">
              <Text className="text-4xl font-bold text-green-500">
                $
              </Text>
            </View>

            <Text className="text-4xl font-bold text-gray-800">
              Sign Up
            </Text>

            <Text className="mt-2 text-base text-gray-500">
              Crie sua conta para começar.
            </Text>

          </View>

          <Text className="mb-2 font-semibold text-gray-700">
            Name
          </Text>

          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="Digite seu nome"
            placeholderTextColor="#9ca3af"
            className="mb-5 rounded-xl border border-gray-300 px-4 py-4 text-base text-gray-800"
          />

          <Text className="mb-2 font-semibold text-gray-700">
            Email
          </Text>

          <TextInput
            value={email}
            onChangeText={setEmail}
            placeholder="Digite seu e-mail"
            placeholderTextColor="#9ca3af"
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            className="mb-5 rounded-xl border border-gray-300 px-4 py-4 text-base text-gray-800"
          />

          <Text className="mb-2 font-semibold text-gray-700">
            Password
          </Text>

          <TextInput
            value={password}
            onChangeText={setPassword}
            placeholder="Digite sua senha"
            placeholderTextColor="#9ca3af"
            secureTextEntry
            className="mb-5 rounded-xl border border-gray-300 px-4 py-4 text-base text-gray-800"
          />

          <Text className="mb-2 font-semibold text-gray-700">
            Confirm Password
          </Text>

          <TextInput
            value={confirmPassword}
            onChangeText={setConfirmPassword}
            placeholder="Digite novamente sua senha"
            placeholderTextColor="#9ca3af"
            secureTextEntry
            className="rounded-xl border border-gray-300 px-4 py-4 text-base text-gray-800"
          />

          <TouchableOpacity
            onPress={handleSignUp}
            className="mt-8 rounded-xl bg-green-500 py-4"
          >
            <Text className="text-center text-lg font-bold text-white">
              Sign Up
            </Text>
          </TouchableOpacity>

          <View className="mt-8 flex-row justify-center">

            <Text className="text-gray-500">
              Already have an account?
            </Text>

            <TouchableOpacity
              onPress={() => navigation.navigate('SignIn')}
            >
              <Text className="ml-2 font-bold text-green-500">
                Sign In
              </Text>
            </TouchableOpacity>

          </View>

        </View>
      </ScrollView>

    </KeyboardAvoidingView>
  );
}